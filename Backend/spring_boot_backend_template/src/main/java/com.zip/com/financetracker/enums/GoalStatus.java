package com.financetracker.enums;

public enum GoalStatus {

	ACTIVE, COMPLETED, CANCELLED
}
