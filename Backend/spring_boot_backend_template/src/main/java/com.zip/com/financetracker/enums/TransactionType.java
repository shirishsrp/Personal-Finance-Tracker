package com.financetracker.enums;

public enum TransactionType {
	INCOME, EXPENSE
}
