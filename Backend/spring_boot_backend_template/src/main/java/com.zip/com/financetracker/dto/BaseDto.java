package com.financetracker.dto;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class BaseDto {

	private LocalDate createdOn;
	private LocalDateTime lastUpdatedOn;
}
