package com.financetracker.enums;

public enum Role {

	USER, ADMIN
}
